

<?php //// INICIO CODIGO 

				
    if( !empty($_GET['url']) ){
        $url = explode( "/" , $_GET['url']);
        if( empty($url[count($url)-1]) ){
            unset($url[count($url)-1]);
        }

        switch( $url[0] ){

case 'home': include('home.php');break;

// ALUNOS		
case 'perfil_aluno':
$id = $url[1];
$id2 = $url[2];
include('perfil_aluno.php');break;			

case 'alunos':
include('alunos.php');break;
				
case 'relatorio_reposicao':
include('relatorio_reposicao.php');break;	
				
case 'gerar_lista_nova':
include('gerar_lista_nova.php');break;					
				
/// remover inicio
			
case 'perfil_unidade2':
$id = $url[1];
include('perfil_unidade2.php');break;	
				
/// remover f
				
case 'sair':
include('sair.php');break;
	
				 /// PAGINA 404
	   default: include('404.php');
        }
    }
	
	?>	